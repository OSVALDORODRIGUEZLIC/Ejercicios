package Ejercicio;

public class Switch {

	public static void main(String[] args) {

		
		
		int x=0;
		
	
		switch(x)
		{
		case 0:
		{
			System.out.println("esta es la opci�n 0");
			break;
			
		}
		
		case 1:
			System.out.println("esla es la opci�n 2");
			
			break;
		
		}
	}

}
