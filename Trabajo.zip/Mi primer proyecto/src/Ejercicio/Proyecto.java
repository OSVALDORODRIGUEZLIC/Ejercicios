package Ejercicio;

public class Proyecto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String nom="hola mundo";
		
		System.out.println(nom);
		
		
	}

}
