package Ejercicio;

public class Constructor {

	public static void main(String[] args) {
		
		Secundaria sec= new Secundaria();
		
		sec.mostrardatos();

	}

}
