package Ejercicio;

public class Secundaria {

 String nombre;
 int edad;
	
	 public Secundaria() {
		 
		 nombre= "david";
		 edad = 22;
		 
	 }
	 
	 
	 
	public void mostrardatos() {

		System.out.println("Tu nombre es" + nombre);

		System.out.println("Tu edad es" + edad);
		
	
	}

}
