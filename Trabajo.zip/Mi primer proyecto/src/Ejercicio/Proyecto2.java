package Ejercicio;

public class Proyecto2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num = 3, num2= 2;
		int suma= num+num2;
		
		System.out.println(suma);
	
		double num3=15.5;
		double num4=20.9;
		double suma2= num3+num4;
		
		System.out.println(suma2);
		
	}

}
