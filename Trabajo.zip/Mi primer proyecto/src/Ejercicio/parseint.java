package Ejercicio;

public class parseint {

	public static void main(String[] args) {
		
		
		
		String cadena="100";
		String cadena2="200";
		
		int convierte=Integer.parseInt(cadena);
		int convierte2=Integer.parseInt(cadena2);
		
		System.out.println(convierte+convierte2);

	}

}
