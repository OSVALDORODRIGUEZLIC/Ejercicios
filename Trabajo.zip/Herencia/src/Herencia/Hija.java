package Herencia;

public class Hija extends Mama {

	public String cocina() {
		return "dulce";
	}
}
