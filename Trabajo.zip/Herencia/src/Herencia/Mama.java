package Herencia;

public class Mama {

	private int edad;
	private String nombre;
	
	public String baila() {
	return "mammbo";	
	}

	public String cocina() {
		return "salado";
	}


	}


