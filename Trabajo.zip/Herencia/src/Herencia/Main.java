package Herencia;

public class Main {

	public static void main(String[] args) {
		Hijo n= new Hijo();
		System.out.println(n.baila());
		System.out.println(n.cocina());

	}

}
