package Herencia;

public class Hijo extends Mama{

public String baila() {
	return "Rock";
}

	}

