
public class suma {

	public static void main(String[] args) {
		
		int a=10, b=123, r;
		
		r= a+b;
		System.out.println("El resultado es \n" + r);
	}
	
}
