
public class ProfesorArtesPlasticas implements Profesor {

	public String exponer() {
		return "AP101-Humanitario";
		
		
	}
	
	public Double evaluar () {
		return 8.5;
	}

	@Override
	public void metodoPrueba() {
		// TODO Auto-generated method stub
		
	}
}
