
public class ProfesorMatematicas implements Profesor {

	public String exponer() {
		return "AP103-Matematicas";
		
		
	}
	
	public Double evaluar () {
		return 6.0;
	}

	@Override
	public void metodoPrueba() {
		// TODO Auto-generated method stub
		
	}
}
