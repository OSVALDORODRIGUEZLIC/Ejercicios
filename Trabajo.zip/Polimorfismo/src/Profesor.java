
public interface Profesor {
public String exponer ();
public  Double evaluar ();

void metodoPrueba();

}
