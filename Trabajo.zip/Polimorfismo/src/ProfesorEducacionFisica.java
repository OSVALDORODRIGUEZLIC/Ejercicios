
public class ProfesorEducacionFisica implements Profesor {

	public String exponer() {
		return "AP102-Fisica";
		
		
	}
	
	public Double evaluar () {
		return 9.5;
	}

	@Override
	public void metodoPrueba() {
		// TODO Auto-generated method stub
		
	}
}
