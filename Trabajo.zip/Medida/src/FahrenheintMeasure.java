
public class FahrenheintMeasure {

}
