
public interface Convert {

	double convert
	
}
