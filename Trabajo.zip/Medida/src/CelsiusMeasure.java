
public class CelsiusMeasure extends Measure {

	public CelsiusMeasure(String name, int minValue, int maxValue, int WaterFrezze) {
		super(name, minValue, maxValue, WaterFrezze);
		

	
}
}
