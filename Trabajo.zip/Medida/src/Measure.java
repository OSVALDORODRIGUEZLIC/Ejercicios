
public class Measure {
private String name;
private int  minValue;
private int maxValue;
private int absZero;
private int waterFrezze;


	public Measure (String name,int minValue, int maxValue, int WaterFrezze )
	{
		
	}
	
}
