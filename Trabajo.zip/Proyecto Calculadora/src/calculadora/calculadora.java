package calculadora;

public class calculadora {

	public double suma(double op1, double op2) {
		return op1+op2;
		
	}
	public double resta(double op1, double op2) {
		return op1-op2;
	}
	
	public double multiplicacion(double op1, double op2) {
		return op1*op2;
	}
	
	public double division(double op1, double op2) {
		return op1/op2;
	}
	
}
