
public class Usuario extends Persona{

public Usuario() {
	super();
}
	public Usuario(String nombre, String email) {
		super(nombre,email);
	}
}
