
public class Administrador extends Persona {

	public Administrador() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Administrador(String nombre, String email) {
		super(nombre, email);
		// TODO Auto-generated constructor stub
	}

	
}
